var LeftNavItem = function(){

}
module.exports = LeftNavItem
