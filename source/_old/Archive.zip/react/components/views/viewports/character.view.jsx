var ViewCharacter = function(){

}
module.exports = ViewCharacter
