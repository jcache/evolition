var EditCharacter = function(){

}
module.exports = EditCharacter
