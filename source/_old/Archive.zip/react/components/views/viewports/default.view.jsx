var DefaultView = function(){

}
module.exports = DefaultView
